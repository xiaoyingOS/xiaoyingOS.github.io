#!/bin/bash

# 获取有线网络IPv4地址
get_wired_ipv4() {
    local wired_ip=''
    
    # 检查操作系统类型
    if [[ "$OSTYPE" == "linux-"* ]]; then
        # Linux/Android
        if command -v ifconfig &> /dev/null; then
            # 有线网接口名称：eth0, eth1, enp0s3, enx开头等
            wired_ip=$(ifconfig 2>/dev/null | grep -E "^(eth|enp|ens|eno|enx)" -A 5 | grep "inet " | grep -v "127.0.0.1" | awk 'NR==1 {print $2}')
        fi
        
        # 如果还是为空，尝试使用ip命令
        if [ -z "$wired_ip" ] && command -v ip &> /dev/null; then
            wired_ip=$(ip -4 addr show 2>/dev/null | grep -E "^(eth|enp|ens|eno|enx)" -A 5 | grep "inet " | grep -oP '(?<=inet\s)\d+(\.\d+){3}' | grep -v "^127\." | head -n1)
        fi
    elif [[ "$OSTYPE" == "darwin"* ]]; then
        # macOS - 获取有线网络接口
        # 使用 networksetup 获取硬件端口信息
        if command -v networksetup &> /dev/null; then
            # 获取有线网卡的设备名称（通常是 "Ethernet" 或 "USB Ethernet"）
            local ethernet_device=$(networksetup -listallhardwareports 2>/dev/null | grep -A 1 "Ethernet" | grep "Device:" | awk '{print $2}' | head -n1)
            if [ -n "$ethernet_device" ]; then
                wired_ip=$(ipconfig getifaddr "$ethernet_device" 2>/dev/null || echo '')
            fi
        fi
        
        # 如果没有找到，尝试使用常见接口名称
        if [ -z "$wired_ip" ]; then
            # 尝试 en0, en1, en2 等有线接口
            for iface in en0 en1 en2 en3; do
                local ip=$(ipconfig getifaddr "$iface" 2>/dev/null)
                if [ -n "$ip" ]; then
                    wired_ip="$ip"
                    break
                fi
            done
        fi
    elif [[ "$OSTYPE" == "msys" ]] || [[ "$OSTYPE" == "win32" ]] || [[ "$OSTYPE" == "cygwin" ]]; then
        # Windows (Git Bash, MSYS, Cygwin)
        # 查找以太网适配器（有线网络）
        # 先尝试英文系统
        wired_ip=$(ipconfig | grep -A 10 "Ethernet adapter" | grep "IPv4 Address" | awk '{print $NF}' | head -n1)
        
        # 如果没找到，尝试中文系统
        if [ -z "$wired_ip" ]; then
            wired_ip=$(ipconfig | grep -A 10 "以太网适配器" | grep "IPv4 地址" | awk '{print $NF}' | head -n1)
        fi
        
        # 排除虚拟网卡（VMware、Hyper-V、VirtualBox等）
        if [ -n "$wired_ip" ]; then
            local adapter_info=$(ipconfig | grep -B 20 "IPv4 Address" | grep -E "^(Ethernet adapter|以太网适配器)" | grep -vEi "(VMware|VirtualBox|Hyper-V|vEthernet|Virtual)" | head -n1)
            if [ -z "$adapter_info" ]; then
                wired_ip=""
            fi
        fi
    fi
    
    # 返回结果（空或IP地址）
    echo "$wired_ip"
}

# 获取无线网络IPv4地址
get_wireless_ipv4() {
    local wireless_ip=''
    
    # 检查操作系统类型
    if [[ "$OSTYPE" == "linux-"* ]]; then
        # Linux/Android
        if command -v ifconfig &> /dev/null; then
            # 无线网接口名称：wlan0, wlan1, wlp开头等
            wireless_ip=$(ifconfig 2>/dev/null | grep -E "^(wlan|wlp|wlan)" -A 5 | grep "inet " | grep -v "127.0.0.1" | awk 'NR==1 {print $2}')
        fi
        
        # 如果还是为空，尝试使用ip命令
        if [ -z "$wireless_ip" ] && command -v ip &> /dev/null; then
            wireless_ip=$(ip -4 addr show 2>/dev/null | grep -E "^(wlan|wlp)" -A 5 | grep "inet " | grep -oP '(?<=inet\s)\d+(\.\d+){3}' | grep -v "^127\." | head -n1)
        fi
    elif [[ "$OSTYPE" == "darwin"* ]]; then
        # macOS - 获取无线网络接口
        # 使用 networksetup 获取硬件端口信息
        if command -v networksetup &> /dev/null; then
            # 获取无线网卡的设备名称（通常是 "Wi-Fi"）
            local wifi_device=$(networksetup -listallhardwareports 2>/dev/null | grep -A 1 "Wi-Fi" | grep "Device:" | awk '{print $2}' | head -n1)
            if [ -n "$wifi_device" ]; then
                wireless_ip=$(ipconfig getifaddr "$wifi_device" 2>/dev/null || echo '')
            fi
        fi
        
        # 如果没有找到，尝试使用常见接口名称
        if [ -z "$wireless_ip" ]; then
            # 尝试 en0, en1, en2 等无线接口
            for iface in en0 en1 en2 en3; do
                local ip=$(ipconfig getifaddr "$iface" 2>/dev/null)
                if [ -n "$ip" ]; then
                    wireless_ip="$ip"
                    break
                fi
            done
        fi
    elif [[ "$OSTYPE" == "msys" ]] || [[ "$OSTYPE" == "win32" ]] || [[ "$OSTYPE" == "cygwin" ]]; then
        # Windows (Git Bash, MSYS, Cygwin)
        # 查找无线网络适配器
        # 先尝试英文系统 - WLAN
        wireless_ip=$(ipconfig | grep -A 10 "Wireless LAN adapter WLAN" | grep "IPv4 Address" | awk '{print $NF}' | head -n1)
        
        # 如果没找到，尝试中文系统 - 无线网络适配器
        if [ -z "$wireless_ip" ]; then
            wireless_ip=$(ipconfig | grep -A 10 "无线网络适配器" | grep "IPv4 地址" | awk '{print $NF}' | head -n1)
        fi
        
        # 如果还没找到，尝试其他Wi-Fi适配器名称
        if [ -z "$wireless_ip" ]; then
            wireless_ip=$(ipconfig | grep -A 10 "Wi-Fi" | grep "IPv4 Address" | awk '{print $NF}' | head -n1)
        fi
    fi
    
    # 返回结果（空或IP地址）
    echo "$wireless_ip"
}

# 获取本机IPv4地址
get_ipv4_address() {
    local ipv4_address='localhost'
    
    # 检查操作系统类型
    if [[ "$OSTYPE" == "darwin"* ]]; then
        # macOS
        ipv4_address=$(ipconfig getifaddr en0 2>/dev/null || echo 'localhost')
    elif [[ "$OSTYPE" == "msys" ]] || [[ "$OSTYPE" == "win32" ]] || [[ "$OSTYPE" == "cygwin" ]]; then
        # Windows (Git Bash, MSYS, Cygwin)
        # 使用 ipconfig 获取 IPv4 地址
        # 优先级：WLAN (只匹配有 IPv4 Address 的) > 无线网络 > 以太网
        
        # 查找 WLAN 适配器中实际有 IPv4 地址的（排除断开连接的）
        ipv4_address=$(ipconfig | grep -A 10 "Wireless LAN adapter WLAN" | grep "IPv4 Address" | awk '{print $NF}' | head -n1)
        
        # 如果没找到，尝试查找"无线网络适配器"
        if [ -z "$ipv4_address" ]; then
            ipv4_address=$(ipconfig | grep -A 10 "无线网络适配器" | grep "IPv4 Address" | awk '{print $NF}' | head -n1)
        fi
        
        # 如果没找到，尝试查找以太网（排除断开连接的）
        if [ -z "$ipv4_address" ]; then
            ipv4_address=$(ipconfig | grep -A 10 "Ethernet adapter" | grep "IPv4 Address" | awk '{print $NF}' | head -n1)
        fi
        
        # 如果没找到，查找所有网络适配器，但排除虚拟网络适配器
        # 排除 VMware、Hyper-V、VirtualBox 等虚拟网卡
        if [ -z "$ipv4_address" ]; then
            ipv4_address=$(ipconfig | grep -B 20 "IPv4 Address" | \
                           grep -E "^(无线局域网适配器|Wireless LAN adapter|以太网适配器|Ethernet adapter)" | \
                           grep -vEi "(VMware|VirtualBox|Hyper-V|vEthernet|Virtual)" | \
                           head -n1 | \
                           while read line; do
                               adapter=$(echo "$line" | sed 's/适配器.*$//;s/adapter.*$//' | tr -d ' ')
                               ipconfig | grep -A 20 "$adapter" | grep "IPv4 Address" | awk '{print $NF}' | head -n1
                           done)
        fi
    elif [[ "$OSTYPE" == "linux-"* ]]; then
        # Linux
        if command -v ip &> /dev/null; then
            local interfaces=$(ip -4 addr show 2>/dev/null | grep -oP '(?<=inet\s)\d+(\.\d+){3}')
            if [ -n "$interfaces" ]; then
                # 过滤掉 127.0.0.1
                ipv4_address=$(echo "$interfaces" | grep -v "^127\." | head -n1)
            fi
        elif command -v ifconfig &> /dev/null; then
            # 使用 ifconfig 作为备选
            ipv4_address=$(ifconfig 2>/dev/null | grep "inet " | grep -v "127.0.0.1" | awk '{print $2}' | head -n1)
        fi
    fi
    
    # 如果还是localhost，尝试使用hostname -I
    if [ "$ipv4_address" == 'localhost' ] || [ -z "$ipv4_address" ]; then
        ipv4_address=$(hostname -I 2>/dev/null | awk '{print $1}')
    fi
    
    # 如果仍然为空，返回 localhost
    if [ -z "$ipv4_address" ]; then
        ipv4_address='localhost'
    fi
    
    echo "$ipv4_address"
}

# 获取IPv4地址（分别获取有线和无线）
LOCAL_IP=$(get_ipv4_address)
WIRED_IP=$(get_wired_ipv4)
WIRELESS_IP=$(get_wireless_ipv4)

echo "=========================================="
echo "   聊天应用服务器启动选择器"
echo "=========================================="
echo ""
echo "请选择启动方式："
echo "1. HTTP服务器 (端口8084) - 视频语音功能受限"
echo "2. HTTPS服务器 (端口8443) - 视频语音功能完全可用"
echo "3. 同时启动HTTP和HTTPS服务器"
echo "4. 停止HTTP服务器"
echo "5. 停止HTTPS服务器"
echo "6. 停止所有服务器 (HTTP + HTTPS)"
echo "7. 停止并重启HTTPS服务器"
echo "8. 退出"
echo ""
read -p "请输入选项 (1-8): " choice

case $choice in
    1)
        echo ""
        echo "正在启动HTTP服务器..."

        # 检查并停止端口8084上的旧服务器
        # 使用更精确的匹配模式避免误匹配脚本自身
        OLD_PID=""
        if command -v pgrep &> /dev/null; then
            # 使用精确匹配：查找以server.js结尾的node进程
            # 排除包含grep、bash、start-server等关键词的进程
            OLD_PID=$(pgrep -af "node.*server\.js$" 2>/dev/null | grep -v -E "(grep|bash|start-server)" | awk '{print $1}' | head -1)
        fi

        # 如果pgrep未找到，尝试使用ps命令
        if [ -z "$OLD_PID" ]; then
            OLD_PID=$(ps aux 2>/dev/null | grep "node.*server\.js$" | grep -v -E "(grep|bash|start-server)" | awk '{print $2}' | head -1)
        fi

        # 兼容Windows netstat格式
        if [ -z "$OLD_PID" ] && command -v netstat &> /dev/null; then
            OLD_PID=$(netstat -ano 2>/dev/null | grep ":8084.*LISTENING" | awk '{print $5}')
        fi

        if [ -n "$OLD_PID" ]; then
            echo "找到旧HTTP服务器进程 (PID: $OLD_PID)"
            # 验证进程确实是node server.js
            if ps -p $OLD_PID -o comm= 2>/dev/null | grep -q "node"; then
                echo "停止旧HTTP服务器 (PID: $OLD_PID)..."
                kill $OLD_PID 2>/dev/null
                sleep 1
                # 如果进程仍在运行，强制终止
                if ps -p $OLD_PID > /dev/null 2>&1; then
                    kill -9 $OLD_PID 2>/dev/null
                fi
                echo "旧HTTP服务器已停止"
            else
                echo "警告：PID $OLD_PID 不是node进程，跳过终止"
                OLD_PID=""
            fi
        else
            echo "未找到运行中的HTTP服务器"
        fi

        echo "访问地址: http://localhost:8084"
        echo "网关访问: http://0.0.0.0:8084"
        
        # 显示有线IP访问地址（如果有）
        if [ -n "$WIRED_IP" ]; then
            echo "有线IP访问: http://${WIRED_IP}:8084"
        fi
        
        # 显示无线IP访问地址（如果有）
        if [ -n "$WIRELESS_IP" ]; then
            echo "无线IP访问: http://${WIRELESS_IP}:8084"
        fi
        
        # 如果没有获取到有线或无线IP，显示通用局域网访问
        if [ -z "$WIRED_IP" ] && [ -z "$WIRELESS_IP" ] && [ -n "$LOCAL_IP" ] && [ "$LOCAL_IP" != "localhost" ]; then
            echo "局域网访问: http://${LOCAL_IP}:8084"
        fi
        echo ""
        echo "注意：HTTP访问时视频语音功能可能受限"
        echo "建议使用HTTPS版本或直接打开HTML文件"
        echo ""

        # 后台启动服务器并记录日志
        nohup node server.js > server.log 2>&1 &
        HTTP_PID=$!

        # 等待服务器启动
        sleep 2

        echo "=========================================="
        echo "HTTP服务器启动成功！"
        echo "=========================================="
        echo ""
        echo "服务器信息："
        echo "  进程ID: $HTTP_PID"
        echo "  日志文件: $(pwd)/server.log"
        echo ""
        echo "服务器输出："
        echo "----------------------------------------"
        cat server.log
        echo "----------------------------------------"
        echo ""
        echo "提示："
        echo "  • 查看日志: tail -f server.log"
        echo "  • 停止服务器: kill $HTTP_PID"
        echo ""

        printf "服务器已后台启动，按任意键继续..."
        read -n1 -s -r
        echo ""
        echo "继续执行脚本！"
        echo ""
        ;;
    2)
        echo ""
        echo "正在启动HTTPS服务器..."
        echo ""

        # 检查并停止端口8443上的旧服务器
        # 优先使用pgrep查找node进程
        OLD_PID=""
        if command -v pgrep &> /dev/null; then
            OLD_PID=$(pgrep -f "node.*server-https.js" 2>/dev/null)
        fi

        # 如果pgrep未找到，尝试使用ps aux命令（跨平台兼容）
        if [ -z "$OLD_PID" ]; then
            OLD_PID=$(ps aux 2>/dev/null | grep "node.*server-https.js" | grep -v grep | awk '{print $2}')
        fi

        # 如果ps aux未找到，尝试使用ps -ef命令（部分系统支持）
        if [ -z "$OLD_PID" ]; then
            OLD_PID=$(ps -ef 2>/dev/null | grep "node.*server-https.js" | grep -v grep | awk '{print $2}')
        fi

        # 兼容Windows netstat格式
        if [ -z "$OLD_PID" ] && command -v netstat &> /dev/null; then
            OLD_PID=$(netstat -ano 2>/dev/null | grep ":8443.*LISTENING" | awk '{print $5}')
        fi

        # Linux ss命令支持（netstat的现代替代）
        if [ -z "$OLD_PID" ] && command -v ss &> /dev/null; then
            OLD_PID=$(ss -tlnp 2>/dev/null | grep ":8443" | grep node | awk '{print $7}' | sed 's/.*pid=\([0-9]*\).*/\1/')
        fi

        if [ -n "$OLD_PID" ]; then
            echo "停止旧服务器 (PID: $OLD_PID)..."
            # Windows: 使用 taskkill
            if command -v taskkill &> /dev/null; then
                taskkill //F //PID $OLD_PID > /dev/null 2>&1
            else
                kill $OLD_PID 2>/dev/null
                sleep 1
                # 如果进程仍在运行，强制终止
                if ps -p $OLD_PID > /dev/null 2>&1; then
                    kill -9 $OLD_PID 2>/dev/null
                fi
            fi
            echo "旧服务器已停止"
        fi

        # 后台启动服务器并记录日志
        nohup node server-https.js > https-server.log 2>&1 &
        SERVER_PID=$!

        # 等待服务器启动
        sleep 2

        echo "=========================================="
        echo "HTTPS服务器启动成功！"
        echo "=========================================="
        echo ""
        echo "服务器信息："
        echo "  进程ID: $SERVER_PID"
        echo "  日志文件: $(pwd)/https-server.log"
        echo ""
        echo "服务器输出："
        echo "----------------------------------------"
        cat https-server.log
        echo "----------------------------------------"
        echo ""
        echo "提示："
        echo "  • 浏览器会提示证书不安全，请点击'高级'然后'继续访问'"
        echo "  • 查看日志: tail -f https-server.log"
        echo "  • 停止服务器: kill $SERVER_PID"
        echo ""
        echo "访问地址："
        echo "  本地访问: https://localhost:8443"
        echo "  网关访问: https://0.0.0.0:8443"
        
        # 显示有线IP访问地址（如果有）
        if [ -n "$WIRED_IP" ]; then
            echo "  有线IP访问: https://${WIRED_IP}:8443"
        fi
        
        # 显示无线IP访问地址（如果有）
        if [ -n "$WIRELESS_IP" ]; then
            echo "  无线IP访问: https://${WIRELESS_IP}:8443"
        fi
        
        # 如果没有获取到有线或无线IP，显示通用局域网访问
        if [ -z "$WIRED_IP" ] && [ -z "$WIRELESS_IP" ] && [ -n "$LOCAL_IP" ] && [ "$LOCAL_IP" != "localhost" ]; then
            echo "  局域网访问: https://${LOCAL_IP}:8443"
        fi
        echo ""
        echo "视频语音功能完全可用"
        echo ""

        printf "服务器已后台启动，按任意键继续..."
        read -n1 -s -r
        echo ""
        echo "继续执行脚本！"
        echo ""
        ;;
    3)
        echo ""
        echo "正在同时启动HTTP和HTTPS服务器..."
        echo ""

        # 检查并停止端口8084上的旧HTTP服务器
        OLD_HTTP_PID=""
        if command -v pgrep &> /dev/null; then
            OLD_HTTP_PID=$(pgrep -af "node.*server\.js$" 2>/dev/null | grep -v -E "(grep|bash|start-server)" | awk '{print $1}' | head -1)
        fi

        if [ -z "$OLD_HTTP_PID" ]; then
            OLD_HTTP_PID=$(ps aux 2>/dev/null | grep "node.*server\.js$" | grep -v -E "(grep|bash|start-server)" | awk '{print $2}' | head -1)
        fi

        if [ -z "$OLD_HTTP_PID" ]; then
            OLD_HTTP_PID=$(ps -ef 2>/dev/null | grep "node.*server\.js$" | grep -v -E "(grep|bash|start-server)" | awk '{print $2}' | head -1)
        fi

        if [ -z "$OLD_HTTP_PID" ] && command -v netstat &> /dev/null; then
            OLD_HTTP_PID=$(netstat -ano 2>/dev/null | grep ":8084.*LISTENING" | awk '{print $5}')
        fi

        if [ -z "$OLD_HTTP_PID" ] && command -v ss &> /dev/null; then
            OLD_HTTP_PID=$(ss -tlnp 2>/dev/null | grep ":8084" | grep node | awk '{print $7}' | sed 's/.*pid=\([0-9]*\).*/\1/')
        fi

        if [ -n "$OLD_HTTP_PID" ]; then
            echo "找到旧HTTP服务器进程 (PID: $OLD_HTTP_PID)"
            if ps -p $OLD_HTTP_PID -o comm= 2>/dev/null | grep -q "node"; then
                echo "停止旧HTTP服务器 (PID: $OLD_HTTP_PID)..."
                kill $OLD_HTTP_PID 2>/dev/null
                sleep 1
                if ps -p $OLD_HTTP_PID > /dev/null 2>&1; then
                    kill -9 $OLD_HTTP_PID 2>/dev/null
                fi
                echo "旧HTTP服务器已停止"
            else
                echo "警告：PID $OLD_HTTP_PID 不是node进程，跳过终止"
                OLD_HTTP_PID=""
            fi
        fi

        # 检查并停止端口8443上的旧HTTPS服务器
        OLD_HTTPS_PID=""
        if command -v pgrep &> /dev/null; then
            OLD_HTTPS_PID=$(pgrep -f "node.*server-https.js" 2>/dev/null)
        fi

        if [ -z "$OLD_HTTPS_PID" ]; then
            OLD_HTTPS_PID=$(ps aux 2>/dev/null | grep "node.*server-https.js" | grep -v grep | awk '{print $2}')
        fi

        if [ -z "$OLD_HTTPS_PID" ]; then
            OLD_HTTPS_PID=$(ps -ef 2>/dev/null | grep "node.*server-https.js" | grep -v grep | awk '{print $2}')
        fi

        if [ -z "$OLD_HTTPS_PID" ] && command -v netstat &> /dev/null; then
            OLD_HTTPS_PID=$(netstat -ano 2>/dev/null | grep ":8443.*LISTENING" | awk '{print $5}')
        fi

        if [ -z "$OLD_HTTPS_PID" ] && command -v ss &> /dev/null; then
            OLD_HTTPS_PID=$(ss -tlnp 2>/dev/null | grep ":8443" | grep node | awk '{print $7}' | sed 's/.*pid=\([0-9]*\).*/\1/')
        fi

        if [ -n "$OLD_HTTPS_PID" ]; then
            echo "找到旧HTTPS服务器进程 (PID: $OLD_HTTPS_PID)"
            echo "停止旧HTTPS服务器 (PID: $OLD_HTTPS_PID)..."
            if command -v taskkill &> /dev/null; then
                taskkill //F //PID $OLD_HTTPS_PID > /dev/null 2>&1
            else
                kill $OLD_HTTPS_PID 2>/dev/null
                sleep 1
                if ps -p $OLD_HTTPS_PID > /dev/null 2>&1; then
                    kill -9 $OLD_HTTPS_PID 2>/dev/null
                fi
            fi
            echo "旧HTTPS服务器已停止"
        fi

        echo ""
        echo "HTTP服务器:"
        echo "  访问地址: http://localhost:8084"
        echo "  网关访问: http://0.0.0.0:8084"
        
        # 显示有线IP访问地址（如果有）
        if [ -n "$WIRED_IP" ]; then
            echo "  有线IP访问: http://${WIRED_IP}:8084"
        fi
        
        # 显示无线IP访问地址（如果有）
        if [ -n "$WIRELESS_IP" ]; then
            echo "  无线IP访问: http://${WIRELESS_IP}:8084"
        fi
        
        # 如果没有获取到有线或无线IP，显示通用局域网访问
        if [ -z "$WIRED_IP" ] && [ -z "$WIRELESS_IP" ] && [ -n "$LOCAL_IP" ] && [ "$LOCAL_IP" != "localhost" ]; then
            echo "  局域网访问: http://${LOCAL_IP}:8084"
        fi
        
        echo ""
        echo "HTTPS服务器:"
        echo "  访问地址: https://localhost:8443"
        echo "  网关访问: https://0.0.0.0:8443"
        
        # 显示有线IP访问地址（如果有）
        if [ -n "$WIRED_IP" ]; then
            echo "  有线IP访问: https://${WIRED_IP}:8443"
        fi
        
        # 显示无线IP访问地址（如果有）
        if [ -n "$WIRELESS_IP" ]; then
            echo "  无线IP访问: https://${WIRELESS_IP}:8443"
        fi
        
        # 如果没有获取到有线或无线IP，显示通用局域网访问
        if [ -z "$WIRED_IP" ] && [ -z "$WIRELESS_IP" ] && [ -n "$LOCAL_IP" ] && [ "$LOCAL_IP" != "localhost" ]; then
            echo "  局域网访问: https://${LOCAL_IP}:8443"
        fi
        echo ""
        echo "建议使用HTTPS版本以获得完整功能"
        echo ""

        # 后台启动服务器并记录日志
        nohup node server.js > server.log 2>&1 &
        HTTP_PID=$!
        nohup node server-https.js > https-server.log 2>&1 &
        HTTPS_PID=$!

        # 等待服务器启动
        sleep 2

        echo ""
        echo "=========================================="
        echo "HTTP和HTTPS服务器同时启动成功！"
        echo "=========================================="
        echo ""
        echo "HTTP服务器进程ID: $HTTP_PID"
        echo "HTTPS服务器进程ID: $HTTPS_PID"
        echo ""
        echo "日志文件："
        echo "  HTTP: $(pwd)/server.log"
        echo "  HTTPS: $(pwd)/https-server.log"
        echo ""

        printf "服务器已后台启动，按任意键继续..."
        read -n1 -s -r
        echo ""
        echo "继续执行脚本！"
        echo ""
        ;;
    4)
        echo ""
        echo "正在停止HTTP服务器..."

        # 查找server.js进程（使用与选项1相同的精确匹配）
        OLD_PID=""
        if command -v pgrep &> /dev/null; then
            # 使用精确匹配：查找以server.js结尾的node进程
            # 排除包含grep、bash、start-server等关键词的进程
            OLD_PID=$(pgrep -af "node.*server\.js$" 2>/dev/null | grep -v -E "(grep|bash|start-server)" | awk '{print $1}' | head -1)
        fi

        if [ -z "$OLD_PID" ]; then
            OLD_PID=$(ps aux 2>/dev/null | grep "node.*server\.js$" | grep -v -E "(grep|bash|start-server)" | awk '{print $2}' | head -1)
        fi

        if [ -z "$OLD_PID" ]; then
            OLD_PID=$(ps -ef 2>/dev/null | grep "node.*server\.js$" | grep -v -E "(grep|bash|start-server)" | awk '{print $2}' | head -1)
        fi

        # 兼容Windows netstat格式
        if [ -z "$OLD_PID" ] && command -v netstat &> /dev/null; then
            OLD_PID=$(netstat -ano 2>/dev/null | grep ":8084.*LISTENING" | awk '{print $5}')
        fi

        if [ -z "$OLD_PID" ] && command -v ss &> /dev/null; then
            OLD_PID=$(ss -tlnp 2>/dev/null | grep ":8084" | grep node | awk '{print $7}' | sed 's/.*pid=\([0-9]*\).*/\1/')
        fi

        if [ -n "$OLD_PID" ]; then
            echo "找到HTTP服务器 (PID: $OLD_PID)"
            # 验证进程确实是node server.js
            if ps -p $OLD_PID -o comm= 2>/dev/null | grep -q "node"; then
                if command -v taskkill &> /dev/null; then
                    taskkill //F //PID $OLD_PID > /dev/null 2>&1
                else
                    kill $OLD_PID 2>/dev/null
                    sleep 1
                    if ps -p $OLD_PID > /dev/null 2>&1; then
                        kill -9 $OLD_PID 2>/dev/null
                    fi
                fi
                echo "HTTP服务器已停止"
            else
                echo "警告：PID $OLD_PID 不是node进程，跳过终止"
            fi
        else
            echo "未找到运行中的HTTP服务器"
        fi
        echo ""
        ;;
    5)
        echo ""
        echo "正在停止HTTPS服务器..."

        # 查找server-https.js进程
        OLD_PID=""
        if command -v pgrep &> /dev/null; then
            OLD_PID=$(pgrep -f "node.*server-https.js" 2>/dev/null)
        fi

        if [ -z "$OLD_PID" ]; then
            OLD_PID=$(ps aux 2>/dev/null | grep "node.*server-https.js" | grep -v grep | awk '{print $2}')
        fi

        if [ -z "$OLD_PID" ]; then
            OLD_PID=$(ps -ef 2>/dev/null | grep "node.*server-https.js" | grep -v grep | awk '{print $2}')
        fi

        # 兼容Windows netstat格式
        if [ -z "$OLD_PID" ] && command -v netstat &> /dev/null; then
            OLD_PID=$(netstat -ano 2>/dev/null | grep ":8443.*LISTENING" | awk '{print $5}')
        fi

        if [ -z "$OLD_PID" ] && command -v ss &> /dev/null; then
            OLD_PID=$(ss -tlnp 2>/dev/null | grep ":8443" | grep node | awk '{print $7}' | sed 's/.*pid=\([0-9]*\).*/\1/')
        fi

        if [ -n "$OLD_PID" ]; then
            echo "找到HTTPS服务器 (PID: $OLD_PID)"
            if command -v taskkill &> /dev/null; then
                taskkill //F //PID $OLD_PID > /dev/null 2>&1
            else
                kill $OLD_PID 2>/dev/null
                sleep 1
                if ps -p $OLD_PID > /dev/null 2>&1; then
                    kill -9 $OLD_PID 2>/dev/null
                fi
            fi
            echo "HTTPS服务器已停止"
        else
            echo "未找到运行中的HTTPS服务器"
        fi
        echo ""
        ;;
    6)
        echo ""
        echo "正在停止所有服务器 (HTTP + HTTPS)..."

        # 停止HTTP服务器（使用精确匹配）
        HTTP_PID=""
        if command -v pgrep &> /dev/null; then
            HTTP_PID=$(pgrep -af "node.*server\.js$" 2>/dev/null | grep -v -E "(grep|bash|start-server)" | awk '{print $1}' | head -1)
        fi

        if [ -z "$HTTP_PID" ]; then
            HTTP_PID=$(ps aux 2>/dev/null | grep "node.*server\.js$" | grep -v -E "(grep|bash|start-server)" | awk '{print $2}' | head -1)
        fi

        if [ -z "$HTTP_PID" ]; then
            HTTP_PID=$(ps -ef 2>/dev/null | grep "node.*server\.js$" | grep -v -E "(grep|bash|start-server)" | awk '{print $2}' | head -1)
        fi

        if [ -z "$HTTP_PID" ] && command -v netstat &> /dev/null; then
            HTTP_PID=$(netstat -ano 2>/dev/null | grep ":8084.*LISTENING" | awk '{print $5}')
        fi

        if [ -z "$HTTP_PID" ] && command -v ss &> /dev/null; then
            HTTP_PID=$(ss -tlnp 2>/dev/null | grep ":8084" | grep node | awk '{print $7}' | sed 's/.*pid=\([0-9]*\).*/\1/')
        fi

        if [ -n "$HTTP_PID" ]; then
            echo "找到HTTP服务器 (PID: $HTTP_PID)"
            # 验证进程确实是node server.js
            if ps -p $HTTP_PID -o comm= 2>/dev/null | grep -q "node"; then
                if command -v taskkill &> /dev/null; then
                    taskkill //F //PID $HTTP_PID > /dev/null 2>&1
                else
                    kill $HTTP_PID 2>/dev/null
                    sleep 1
                    if ps -p $HTTP_PID > /dev/null 2>&1; then
                        kill -9 $HTTP_PID 2>/dev/null
                    fi
                fi
                echo "HTTP服务器已停止"
            else
                echo "警告：PID $HTTP_PID 不是node进程，跳过终止"
            fi
        else
            echo "未找到运行中的HTTP服务器"
        fi

        # 停止HTTPS服务器
        HTTPS_PID=""
        if command -v pgrep &> /dev/null; then
            HTTPS_PID=$(pgrep -f "node.*server-https.js" 2>/dev/null)
        fi

        if [ -z "$HTTPS_PID" ]; then
            HTTPS_PID=$(ps aux 2>/dev/null | grep "node.*server-https.js" | grep -v grep | awk '{print $2}')
        fi

        if [ -z "$HTTPS_PID" ]; then
            HTTPS_PID=$(ps -ef 2>/dev/null | grep "node.*server-https.js" | grep -v grep | awk '{print $2}')
        fi

        if [ -z "$HTTPS_PID" ] && command -v netstat &> /dev/null; then
            HTTPS_PID=$(netstat -ano 2>/dev/null | grep ":8443.*LISTENING" | awk '{print $5}')
        fi

        if [ -z "$HTTPS_PID" ] && command -v ss &> /dev/null; then
            HTTPS_PID=$(ss -tlnp 2>/dev/null | grep ":8443" | grep node | awk '{print $7}' | sed 's/.*pid=\([0-9]*\).*/\1/')
        fi

        if [ -n "$HTTPS_PID" ]; then
            echo "找到HTTPS服务器 (PID: $HTTPS_PID)"
            if command -v taskkill &> /dev/null; then
                taskkill //F //PID $HTTPS_PID > /dev/null 2>&1
            else
                kill $HTTPS_PID 2>/dev/null
                sleep 1
                if ps -p $HTTPS_PID > /dev/null 2>&1; then
                    kill -9 $HTTPS_PID 2>/dev/null
                fi
            fi
            echo "HTTPS服务器已停止"
        else
            echo "未找到运行中的HTTPS服务器"
        fi

        echo ""
        echo "所有服务器已停止"
        echo ""
        ;;
    7)
        echo ""
        echo "正在停止并重启HTTPS服务器..."

        # 停止旧服务器（查找server-https.js进程）
        OLD_PID=""
        if command -v pgrep &> /dev/null; then
            OLD_PID=$(pgrep -f "node.*server-https.js" 2>/dev/null)
        fi

        if [ -z "$OLD_PID" ]; then
            OLD_PID=$(ps aux 2>/dev/null | grep "node.*server-https.js" | grep -v grep | awk '{print $2}')
        fi

        if [ -z "$OLD_PID" ]; then
            OLD_PID=$(ps -ef 2>/dev/null | grep "node.*server-https.js" | grep -v grep | awk '{print $2}')
        fi

        # 兼容Windows netstat格式
        if [ -z "$OLD_PID" ] && command -v netstat &> /dev/null; then
            OLD_PID=$(netstat -ano 2>/dev/null | grep ":8443.*LISTENING" | awk '{print $5}')
        fi

        if [ -z "$OLD_PID" ] && command -v ss &> /dev/null; then
            OLD_PID=$(ss -tlnp 2>/dev/null | grep ":8443" | grep node | awk '{print $7}' | sed 's/.*pid=\([0-9]*\).*/\1/')
        fi

        if [ -n "$OLD_PID" ]; then
            echo "停止旧服务器 (PID: $OLD_PID)..."
            if command -v taskkill &> /dev/null; then
                taskkill //F //PID $OLD_PID > /dev/null 2>&1
            else
                kill $OLD_PID 2>/dev/null
                sleep 1
                if ps -p $OLD_PID > /dev/null 2>&1; then
                    kill -9 $OLD_PID 2>/dev/null
                fi
            fi
            echo "旧服务器已停止"
        else
            echo "未找到运行中的服务器，将启动新服务器"
        fi

        echo ""
        echo "正在启动HTTPS服务器..."
        echo ""

        # 后台启动服务器并记录日志
        nohup node server-https.js > https-server.log 2>&1 &
        SERVER_PID=$!

        # 等待服务器启动
        sleep 2

        echo "=========================================="
        echo "HTTPS服务器启动成功！"
        echo "=========================================="
        echo ""
        echo "服务器信息："
        echo "  进程ID: $SERVER_PID"
        echo "  日志文件: $(pwd)/https-server.log"
        echo ""
        echo "服务器输出："
        echo "----------------------------------------"
        cat https-server.log
        echo "----------------------------------------"
        echo ""
        echo "提示："
        echo "  • 浏览器会提示证书不安全，请点击'高级'然后'继续访问'"
        echo "  • 查看日志: tail -f https-server.log"
        echo "  • 停止服务器: kill $SERVER_PID"
        echo ""
        echo "访问地址："
        echo "  本地访问: https://localhost:8443"
        echo "  网关访问: https://0.0.0.0:8443"
        
        # 显示有线IP访问地址（如果有）
        if [ -n "$WIRED_IP" ]; then
            echo "  有线IP访问: https://${WIRED_IP}:8443"
        fi
        
        # 显示无线IP访问地址（如果有）
        if [ -n "$WIRELESS_IP" ]; then
            echo "  无线IP访问: https://${WIRELESS_IP}:8443"
        fi
        
        # 如果没有获取到有线或无线IP，显示通用局域网访问
        if [ -z "$WIRED_IP" ] && [ -z "$WIRELESS_IP" ] && [ -n "$LOCAL_IP" ] && [ "$LOCAL_IP" != "localhost" ]; then
            echo "  局域网访问: https://${LOCAL_IP}:8443"
        fi
        echo ""
        echo "视频语音功能完全可用"
        echo ""

        printf "服务器已后台启动，按任意键继续..."
        read -n1 -s -r
        echo ""
        echo "继续执行脚本！"
        echo ""
        ;;
    8)
        echo "退出"
        exit 0
        ;;
    *)
        echo "无效选项，请重新运行脚本"
        exit 1
        ;;
esac